var class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_modifiable_element_base =
[
    [ "ModifiableElementBase", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_modifiable_element_base.html#ae08bc0a080682a8988637c9ace9a5d19", null ],
    [ "FinalizeModification", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_modifiable_element_base.html#a8accfc43f01a5cae881ce10d2f69970a", null ],
    [ "Modifier", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_modifiable_element_base.html#a414fa6806497340f22c78afb9b1058ab", null ],
    [ "Modify", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_modifiable_element_base.html#a5a1391b2b30b7538004342680dd7dcd8", null ],
    [ "SetAnchorPoint", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_modifiable_element_base.html#adce0a90cdad2f2128f4274ae5742bf51", null ],
    [ "SetObjectId", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_modifiable_element_base.html#a595e89f3181cf0f58823d061d5486327", null ],
    [ "SetOrientation", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_modifiable_element_base.html#a2f833b29f0e5f2ed21cf03299fdfa0fe", null ]
];