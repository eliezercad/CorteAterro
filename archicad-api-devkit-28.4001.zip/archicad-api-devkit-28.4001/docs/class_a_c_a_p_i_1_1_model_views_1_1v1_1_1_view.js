var class_a_c_a_p_i_1_1_model_views_1_1v1_1_1_view =
[
    [ "GetGuid", "class_a_c_a_p_i_1_1_model_views_1_1v1_1_1_view.html#a6bffdac6d1b5ce074dd0f02c73081d84", null ],
    [ "FindViewByGuid", "class_a_c_a_p_i_1_1_model_views_1_1v1_1_1_view.html#a4567ef5fb58d4c6c5d69fd6bd6b26db3", null ]
];