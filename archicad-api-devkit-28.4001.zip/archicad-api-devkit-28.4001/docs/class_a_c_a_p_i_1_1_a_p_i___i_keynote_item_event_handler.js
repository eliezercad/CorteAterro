var class_a_c_a_p_i_1_1_a_p_i___i_keynote_item_event_handler =
[
    [ "Dispatch", "class_a_c_a_p_i_1_1_a_p_i___i_keynote_item_event_handler.html#a20b1c16ea20d0da88e131f4dd3e36dd2", null ],
    [ "GetName", "class_a_c_a_p_i_1_1_a_p_i___i_keynote_item_event_handler.html#ab217b961c8333c5d8eedfc49cbd5130c", null ]
];