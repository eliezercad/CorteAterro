var class_a_p_i___i_attribute_event_handler =
[
    [ "Dispatch", "class_a_p_i___i_attribute_event_handler.html#a14326295df4c71d96ce6876ed7690906", null ],
    [ "GetName", "class_a_p_i___i_attribute_event_handler.html#a1ac67e203417d07a3a727a9371c12426", null ]
];