var class_a_c_a_p_i_1_1_license_info_1_1v1_1_1_license_info_manager =
[
    [ "GetProductVersionInfo", "group___license_info.html#ga0063de840c45a8aec307ff558f3fc896", null ],
    [ "GetLicenseInfoManager", "class_a_c_a_p_i_1_1_license_info_1_1v1_1_1_license_info_manager.html#a30ffb8a534512a6dfa642b9837168b30", null ]
];