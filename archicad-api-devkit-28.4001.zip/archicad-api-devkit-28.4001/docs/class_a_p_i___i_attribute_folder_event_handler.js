var class_a_p_i___i_attribute_folder_event_handler =
[
    [ "Dispatch", "class_a_p_i___i_attribute_folder_event_handler.html#a3ebf597667162aa0abe021306593395b", null ],
    [ "GetName", "class_a_p_i___i_attribute_folder_event_handler.html#ad86fd42d6220c0caf24a2b52f0982167", null ]
];