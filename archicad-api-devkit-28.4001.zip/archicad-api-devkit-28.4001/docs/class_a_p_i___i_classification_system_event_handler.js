var class_a_p_i___i_classification_system_event_handler =
[
    [ "Dispatch", "class_a_p_i___i_classification_system_event_handler.html#a3b27778c41cc3a7b42d7efc5d8e069c7", null ],
    [ "GetName", "class_a_p_i___i_classification_system_event_handler.html#ae78e529d32904e296d48a83755b30500", null ]
];