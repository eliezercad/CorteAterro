var class_i_f_c_a_p_i_1_1v1_1_1_classification_reference =
[
    [ "GetIdentification", "group___i_f_c.html#gaf2a69b183533a8cb527b14213824e88a", null ],
    [ "GetIfcRelAssociatesClassificationName", "group___i_f_c.html#gaec48e78fe17bc9b1590261cc442604be", null ],
    [ "GetLocation", "group___i_f_c.html#ga14574a763bdeb030dbb7a4f0d5f81713", null ],
    [ "GetName", "group___i_f_c.html#ga80ca9f37615fd366912b7672324b2210", null ],
    [ "GetReferencedSource", "group___i_f_c.html#gae0f8e91234f35a14e6d75fa528403698", null ]
];