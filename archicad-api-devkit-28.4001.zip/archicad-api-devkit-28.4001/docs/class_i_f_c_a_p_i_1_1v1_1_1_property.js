var class_i_f_c_a_p_i_1_1v1_1_1_property =
[
    [ "GetName", "group___i_f_c.html#ga50e55f8adad93b49b1810913d63843fe", null ],
    [ "GetPropertySetName", "group___i_f_c.html#gab064295af33065f2b83769c045e92099", null ],
    [ "GetTyped", "group___i_f_c.html#ga9fb52254079e46c070d1c6f398fe6760", null ]
];