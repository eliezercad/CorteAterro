var class_a_c_a_p_i_1_1v1_1_1_element_base =
[
    [ "ElementBase", "class_a_c_a_p_i_1_1v1_1_1_element_base.html#a03e16f11c20ee53701f242662da653b7", null ],
    [ "GetElemId", "class_a_c_a_p_i_1_1v1_1_1_element_base.html#a91ff68d27443844be4e67b00c721b40e", null ],
    [ "IsEditable", "class_a_c_a_p_i_1_1v1_1_1_element_base.html#a2614e89fdeaf9f1eeffe8cda237fcced", null ]
];