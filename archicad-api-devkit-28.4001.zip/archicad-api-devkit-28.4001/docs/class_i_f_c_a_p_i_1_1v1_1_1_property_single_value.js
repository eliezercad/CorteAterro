var class_i_f_c_a_p_i_1_1v1_1_1_property_single_value =
[
    [ "GetNominalValue", "group___i_f_c.html#gae190e13c9bb2a885138e319f68379c59", null ]
];