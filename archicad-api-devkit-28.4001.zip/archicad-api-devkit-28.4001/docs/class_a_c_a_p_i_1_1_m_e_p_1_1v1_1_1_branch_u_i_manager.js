var class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_branch_u_i_manager =
[
    [ "ApplyBranchDefaultToToolUIData", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_branch_u_i_manager.html#a5b94027fe953609958a189a48c03daa4", null ],
    [ "CreateBranchDefaultFromToolUIData", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_branch_u_i_manager.html#a0f7f8cc3411dadd66359552029c6d67e", null ],
    [ "CreateBranchUIManager", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_branch_u_i_manager.html#ad75e233c48028aef53faae205a3bfce5", null ]
];