var class_a_p_i___i_marquee_event_handler =
[
    [ "Dispatch", "class_a_p_i___i_marquee_event_handler.html#a40582bc9535866aff3dc0196965f3413", null ],
    [ "GetName", "class_a_p_i___i_marquee_event_handler.html#a1882ddba16029d6e67aa2e23636bbf37", null ],
    [ "OnMarqueeChanged", "class_a_p_i___i_marquee_event_handler.html#a9f06eb9f1c18dd69f051486e1f9c8391", null ]
];