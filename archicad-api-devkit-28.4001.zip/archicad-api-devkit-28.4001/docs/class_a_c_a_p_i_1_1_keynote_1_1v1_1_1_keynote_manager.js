var class_a_c_a_p_i_1_1_keynote_1_1v1_1_1_keynote_manager =
[
    [ "AutoTextTokenSelector", "group___keynote.html#ga94a7e51b87cac8540711f768c6cc888b", [
      [ "Key", "class_a_c_a_p_i_1_1_keynote_1_1v1_1_1_keynote_manager.html#ga94a7e51b87cac8540711f768c6cc888ba897356954c2cd3d41b221e3f24f99bba", null ],
      [ "Title", "class_a_c_a_p_i_1_1_keynote_1_1v1_1_1_keynote_manager.html#ga94a7e51b87cac8540711f768c6cc888bab78a3223503896721cca1303f776159b", null ],
      [ "Description", "class_a_c_a_p_i_1_1_keynote_1_1v1_1_1_keynote_manager.html#ga94a7e51b87cac8540711f768c6cc888bab5a7adde1af5c87d7fd797b6245c2a39", null ],
      [ "Reference", "class_a_c_a_p_i_1_1_keynote_1_1v1_1_1_keynote_manager.html#ga94a7e51b87cac8540711f768c6cc888ba63d5049791d9d79d86e9a108b0a999ca", null ]
    ] ],
    [ "GetAutoTextTokenFor", "class_a_c_a_p_i_1_1_keynote_1_1v1_1_1_keynote_manager.html#af1db17f42b566698acf360da889a8058", null ],
    [ "GetRootFolder", "class_a_c_a_p_i_1_1_keynote_1_1v1_1_1_keynote_manager.html#a6dc9a2c7636ec2078e693e3dc5f4e2d8", null ],
    [ "CreateKeynoteManager", "class_a_c_a_p_i_1_1_keynote_1_1v1_1_1_keynote_manager.html#ace6a834a58932ee5fd3279d34f9e5807", null ]
];