var class_a_p_i___i_classification_item_event_handler =
[
    [ "Dispatch", "class_a_p_i___i_classification_item_event_handler.html#acc9e22dbddb23d989c593f0b1053e73f", null ],
    [ "GetName", "class_a_p_i___i_classification_item_event_handler.html#a139dd7983cdcf97395a44272634831a7", null ]
];