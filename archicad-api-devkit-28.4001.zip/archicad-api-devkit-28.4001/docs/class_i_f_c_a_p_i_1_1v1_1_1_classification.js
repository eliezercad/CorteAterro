var class_i_f_c_a_p_i_1_1v1_1_1_classification =
[
    [ "GetDescription", "group___i_f_c.html#ga08fffdbbecb1c8b1df4a0c158bcd43b1", null ],
    [ "GetEdition", "group___i_f_c.html#ga77dbe957ce1a81248b787068bbb86d03", null ],
    [ "GetEditionDate", "group___i_f_c.html#ga038342f75dadf0cedbdf27d6f1f95256", null ],
    [ "GetLocation", "group___i_f_c.html#gaa773b417d30297a8ba0f66a091a09456", null ],
    [ "GetName", "group___i_f_c.html#gacce32f91658c4fafc1632116ec13b398", null ],
    [ "GetSource", "group___i_f_c.html#ga5b80172586d9cabd5bb342d80df5adae", null ]
];