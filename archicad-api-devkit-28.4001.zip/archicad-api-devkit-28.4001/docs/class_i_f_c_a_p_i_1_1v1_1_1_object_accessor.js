var class_i_f_c_a_p_i_1_1v1_1_1_object_accessor =
[
    [ "CreateElementObjectID", "group___i_f_c.html#gab707ec0961a7fb2f62d05357a1a67bf2", null ],
    [ "CreateIfcBuildingObjectID", "group___i_f_c.html#gab1879a9e09f3df0310077dec26d404b5", null ],
    [ "CreateIfcBuildingStoreyObjectID", "group___i_f_c.html#ga484421fff65aabef58757bfdd506263c", null ],
    [ "CreateIfcProjectObjectID", "group___i_f_c.html#ga1daf9fb8777990ffa8a4c8b2e8acf81e", null ],
    [ "CreateIfcSiteObjectID", "group___i_f_c.html#ga9884215ef12e19b51ab87d8f5cd2100e", null ],
    [ "FindElementsByGlobalId", "group___i_f_c.html#gad35b63506cf2bc86158299d9d8b797f7", null ],
    [ "GetAPIElementID", "group___i_f_c.html#ga28f95001a3b43afca8229460004e27d1", null ],
    [ "GetAssignments", "group___i_f_c.html#ga09a917867174665760bf395e677ac1f0", null ],
    [ "GetExternalGlobalId", "group___i_f_c.html#gad9cfc11861c791a3ea2f362a703715b5", null ],
    [ "GetGlobalId", "group___i_f_c.html#gad6b5c5a570181a74390b596525729df1", null ],
    [ "GetIFCType", "group___i_f_c.html#ga1a7984d327ad1bc8ae5f8d00fe55b3a4", null ],
    [ "GetStoryIndex", "group___i_f_c.html#ga7acc680a73a0778c33ce1e504bcf7c27", null ],
    [ "GetTypeObjectIFCType", "group___i_f_c.html#gac27b140636841a8edbb5a05655c2c551", null ],
    [ "GetObjectAccessor", "class_i_f_c_a_p_i_1_1v1_1_1_object_accessor.html#a91d1ab5cbe5f771a21b85582f2701459", null ]
];