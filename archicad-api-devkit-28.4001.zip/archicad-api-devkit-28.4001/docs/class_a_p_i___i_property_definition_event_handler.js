var class_a_p_i___i_property_definition_event_handler =
[
    [ "Dispatch", "class_a_p_i___i_property_definition_event_handler.html#a86de30e75f96cf0c938e5c69194b2723", null ],
    [ "GetName", "class_a_p_i___i_property_definition_event_handler.html#a27bae7a0dfb79b8a55f6e78ec9421545", null ]
];