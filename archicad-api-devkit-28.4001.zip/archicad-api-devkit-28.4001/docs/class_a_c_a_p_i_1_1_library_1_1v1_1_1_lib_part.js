var class_a_c_a_p_i_1_1_library_1_1v1_1_1_lib_part =
[
    [ "GetLocation", "group___library_management.html#gab4106f900cde1f734ff5a850dd7a14d1", null ],
    [ "GetName", "group___library_management.html#gaddfe24ed6a71c9539766b71b0ab04851", null ],
    [ "GetType", "group___library_management.html#gab3d49565b0b7764eab5ec79f3bb92b83", null ]
];