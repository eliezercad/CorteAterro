var class_a_c_a_p_i_1_1_library_1_1v1_1_1_library_tree_path =
[
    [ "GetLastPart", "group___library_management.html#ga6c6f2af2abdb62f80fcebf1915ff4282", null ],
    [ "GetParent", "group___library_management.html#ga218a29736cab1c7d9a62656b57a46338", null ],
    [ "GetParts", "group___library_management.html#gaf7bc0edc69f98200c33b4af45da3d3b3", null ],
    [ "IsRoot", "group___library_management.html#ga526a302ad5490d1931acdd30cae57ae3", null ]
];