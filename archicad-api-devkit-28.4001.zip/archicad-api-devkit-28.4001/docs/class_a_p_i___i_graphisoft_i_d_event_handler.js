var class_a_p_i___i_graphisoft_i_d_event_handler =
[
    [ "Dispatch", "class_a_p_i___i_graphisoft_i_d_event_handler.html#a9698ba10ff842876803d85ef811f042b", null ],
    [ "GetName", "class_a_p_i___i_graphisoft_i_d_event_handler.html#a8c5ceb32c73f6582ad9c68a22d15b8f8", null ],
    [ "OnUserChanged", "class_a_p_i___i_graphisoft_i_d_event_handler.html#aa38597dc4487d36b6f3f37a00da9b44c", null ]
];