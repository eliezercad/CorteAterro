var class_a_c_a_p_i_1_1_a_p_i___i_keynote_event_notifier =
[
    [ "NotifyKeynoteFolderChanges", "class_a_c_a_p_i_1_1_a_p_i___i_keynote_event_notifier.html#a7ffe81ff1d96f27a7df36b4a02925d67", null ],
    [ "NotifyKeynoteItemChanges", "class_a_c_a_p_i_1_1_a_p_i___i_keynote_event_notifier.html#a0d99da22a1b72161c8878c81abe0ef9a", null ]
];