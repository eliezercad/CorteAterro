var class_a_c_a_p_i_1_1v1_1_1_zone_boundary =
[
    [ "GetArea", "class_a_c_a_p_i_1_1v1_1_1_zone_boundary.html#afdab1412cf0456c2baede5798ce392ce", null ],
    [ "GetBody", "class_a_c_a_p_i_1_1v1_1_1_zone_boundary.html#ab45e4ec74e251b5311777ea75f720802", null ],
    [ "GetElemId", "class_a_c_a_p_i_1_1v1_1_1_zone_boundary.html#a39e179991758e261a73f62409de34b70", null ],
    [ "GetNeighbouringZoneId", "class_a_c_a_p_i_1_1v1_1_1_zone_boundary.html#af5beb4d16108c0aaba1bfc9e737ae9f4", null ],
    [ "GetPolygon", "class_a_c_a_p_i_1_1v1_1_1_zone_boundary.html#a304e03a0fc4d6eddb2497c181f271444", null ],
    [ "IsExternal", "class_a_c_a_p_i_1_1v1_1_1_zone_boundary.html#a062c7043bbf5a4f0cc5456e6e4c9efb0", null ]
];