var class_i_f_c_a_p_i_1_1v1_1_1_attribute =
[
    [ "GetName", "group___i_f_c.html#ga10dbb369bdd413c3f1a9f6e7ec62434b", null ],
    [ "GetValue", "group___i_f_c.html#gab49bce53b490c8be0e50cf7992d66279", null ],
    [ "GetValueType", "group___i_f_c.html#ga885a1972163d39228ebc592d540a067f", null ]
];