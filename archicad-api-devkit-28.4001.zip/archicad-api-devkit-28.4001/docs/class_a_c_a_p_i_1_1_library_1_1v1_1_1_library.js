var class_a_c_a_p_i_1_1_library_1_1v1_1_1_library =
[
    [ "GetLocation", "group___library_management.html#ga0b7159ebf6487c0f8ba8d7c4e50d743d", null ],
    [ "GetName", "group___library_management.html#gad6b80823abbc00b5a77a61fad662da55", null ],
    [ "GetPackageDependencies", "group___library_management.html#ga97e899b02c961411a8dd3cd9174cf576", null ],
    [ "GetPackageID", "group___library_management.html#gade6e5a02815d4c7ec3e036cd5a4ef672", null ],
    [ "GetPackageMainVersion", "group___library_management.html#gaea5dcd77f1cd2027a4aa3a793031f163", null ],
    [ "GetPackageMinACBuildNumber", "group___library_management.html#ga43c2fb2949a247c034fb5b0c31f9a410", null ],
    [ "GetPackageMinACVersion", "group___library_management.html#gaf6877835aa54c5dc9ab83891802ba54f", null ],
    [ "GetPackageSubVersion", "group___library_management.html#gab5394540dabc3e174b75a4b24fa29795", null ],
    [ "GetTWServerPath", "group___library_management.html#ga174a53abe91a2b16e75416ff03dcdd1b", null ],
    [ "GetTWServerUrl", "group___library_management.html#ga67578f54e78f502b4faa53bae14d0187", null ],
    [ "IsBuiltIn", "group___library_management.html#gaa7f2b3fc45b6adfbd51323b8338b96b6", null ],
    [ "IsEmbedded", "group___library_management.html#ga58a7586e9e28eb2c099b5504d2805bdf", null ],
    [ "IsLocal", "group___library_management.html#ga61ce1e69519e9447d8b9c6f54932c7ac", null ],
    [ "IsPackage", "group___library_management.html#ga060e4710c0938ced5c72dcd9a43e59e3", null ],
    [ "IsServer", "group___library_management.html#gac173df6286e711079f1dba8402c0be5f", null ]
];