var class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_duct_rectangular_segment_preference_table =
[
    [ "AddNewPreference", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_duct_rectangular_segment_preference_table.html#a720bfbbbf9e9767d3ce1c262347010e9", null ],
    [ "Delete", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_duct_rectangular_segment_preference_table.html#a0666b5d55ede40dda454079af5d23042", null ],
    [ "Exists", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_duct_rectangular_segment_preference_table.html#a8ed6a3ccbdaa34efe1ee1df7877bd5be", null ],
    [ "FinalizeModification", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_duct_rectangular_segment_preference_table.html#a3e45898728f0d3e7dde58ebee2d765a1", null ],
    [ "GetDescription", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_duct_rectangular_segment_preference_table.html#a3213ded3853dfb058afdacf8329c2b81", null ],
    [ "GetName", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_duct_rectangular_segment_preference_table.html#a98ab82f8a9b07745b65752ec02f9e445", null ],
    [ "GetSize", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_duct_rectangular_segment_preference_table.html#a5ecde60d0cdf1cfe5d6ee53cf8569150", null ],
    [ "GetValue", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_duct_rectangular_segment_preference_table.html#a97523b98eb88260d59ac9baa362a7e1b", null ],
    [ "IsEditable", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_duct_rectangular_segment_preference_table.html#a1530c70a3a73a5f2fac829c28d836a8a", null ],
    [ "Modifier", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_duct_rectangular_segment_preference_table.html#a70db9715a7cae4b01acf2592c8f670e8", null ],
    [ "Modify", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_duct_rectangular_segment_preference_table.html#a12814f0fff99b7e621382816a1461f71", null ],
    [ "SetDescription", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_duct_rectangular_segment_preference_table.html#a22a01c5a64e06e9039c01fd6fdf636c5", null ],
    [ "SetName", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_duct_rectangular_segment_preference_table.html#a228772731d324188c30a22cdba481667", null ],
    [ "SetValue", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_duct_rectangular_segment_preference_table.html#a173a4c492be68fd277e0b33cb1747199", null ]
];