var class_i_navigator_callback_interface =
[
    [ "ContextMenuCommand", "class_i_navigator_callback_interface.html#ad6d8d80f6b6a1ebdfc61fb917468b6f4", [
      [ "NewItemCommand", "class_i_navigator_callback_interface.html#ad6d8d80f6b6a1ebdfc61fb917468b6f4a58ead3f2911c0f1c7a118c3d5c8a67a2", null ],
      [ "DeleteItemCommand", "class_i_navigator_callback_interface.html#ad6d8d80f6b6a1ebdfc61fb917468b6f4aa782bdcf2ada23c2449bdf5f23b6fb71", null ],
      [ "RenameItemCommand", "class_i_navigator_callback_interface.html#ad6d8d80f6b6a1ebdfc61fb917468b6f4acf5b693e1f365f6faf755c7805654eaf", null ],
      [ "OpenSettingsCommand", "class_i_navigator_callback_interface.html#ad6d8d80f6b6a1ebdfc61fb917468b6f4a4d172209d15c456949653c4b4174a4fe", null ]
    ] ],
    [ "IconContext", "class_i_navigator_callback_interface.html#afdcb8b510056bb809550c631e86e2ab7", [
      [ "Model", "class_i_navigator_callback_interface.html#afdcb8b510056bb809550c631e86e2ab7a1e08ac6c7d47750ef3fb49ede23c6475", null ],
      [ "Layout", "class_i_navigator_callback_interface.html#afdcb8b510056bb809550c631e86e2ab7ad352a0fa390ff3e124de1db386c13f5e", null ]
    ] ],
    [ "IconLinkness", "class_i_navigator_callback_interface.html#aec7dba4399a8d4ee08f3a669f8b99af5", [
      [ "Normal", "class_i_navigator_callback_interface.html#aec7dba4399a8d4ee08f3a669f8b99af5abe9eaff5fc39ef88a5508f50c5e92b77", null ],
      [ "Link", "class_i_navigator_callback_interface.html#aec7dba4399a8d4ee08f3a669f8b99af5acfebf09b60644531a9fd20e37de273a7", null ],
      [ "Shortcut", "class_i_navigator_callback_interface.html#aec7dba4399a8d4ee08f3a669f8b99af5a571e0482fd4d512ee05fb4efa04b8b64", null ],
      [ "PDFShortcut", "class_i_navigator_callback_interface.html#aec7dba4399a8d4ee08f3a669f8b99af5a85be0033671559686db006e1e9e578d9", null ],
      [ "DWGShortcut", "class_i_navigator_callback_interface.html#aec7dba4399a8d4ee08f3a669f8b99af5a6808369c034537da1d3ca6a8ec334110", null ],
      [ "DXFShortcut", "class_i_navigator_callback_interface.html#aec7dba4399a8d4ee08f3a669f8b99af5ac846da77b558862168357aabed2adee7", null ],
      [ "IFCShortcut", "class_i_navigator_callback_interface.html#aec7dba4399a8d4ee08f3a669f8b99af5af93c75bd5bedbd3f347c5647439eecdb", null ]
    ] ],
    [ "IconSize", "class_i_navigator_callback_interface.html#a92bd550ac1d85fb39c68621f90375209", [
      [ "NormalSize", "class_i_navigator_callback_interface.html#a92bd550ac1d85fb39c68621f90375209ac379fe33be51e5f7c13377c8b42dd122", null ],
      [ "Small", "class_i_navigator_callback_interface.html#a92bd550ac1d85fb39c68621f90375209a112912e231ed94196c742ade054e7214", null ]
    ] ],
    [ "IconTWMode", "class_i_navigator_callback_interface.html#a4bdd78950d7b8b5e6f3946302aa5be96", [
      [ "TWNormal", "class_i_navigator_callback_interface.html#a4bdd78950d7b8b5e6f3946302aa5be96af241d32bae7306a45841d3189a34d062", null ],
      [ "TWReserved", "class_i_navigator_callback_interface.html#a4bdd78950d7b8b5e6f3946302aa5be96a03135543836ac2c01751619bbe8597a8", null ],
      [ "TWBeforeSend", "class_i_navigator_callback_interface.html#a4bdd78950d7b8b5e6f3946302aa5be96a5df32a623731ca0e74c808562d308c85", null ],
      [ "TWNotMineBeforeSend", "class_i_navigator_callback_interface.html#a4bdd78950d7b8b5e6f3946302aa5be96ae729cb2028afab3bba47056aef4f5958", null ]
    ] ],
    [ "TWCommandMail", "class_i_navigator_callback_interface.html#a75aea59f5cc75698d21752951a196332", [
      [ "Request1Mail", "class_i_navigator_callback_interface.html#a75aea59f5cc75698d21752951a196332aea9f51a221cd0863ddfdcaa9ff25a282", null ],
      [ "RequestNMail", "class_i_navigator_callback_interface.html#a75aea59f5cc75698d21752951a196332a1bc81629482d24dc9a0925e2656c2b92", null ],
      [ "Grant1Mail", "class_i_navigator_callback_interface.html#a75aea59f5cc75698d21752951a196332a1ad08b19b864ebb311f47b89fdd4f5d2", null ],
      [ "GrantNMail", "class_i_navigator_callback_interface.html#a75aea59f5cc75698d21752951a196332a808895778c679d9c1083ae0d9d64ba32", null ]
    ] ],
    [ "TWCommandMenu", "class_i_navigator_callback_interface.html#a37421ea9a0ba554f11d4fb63b4b0943d", [
      [ "ReserveNode", "class_i_navigator_callback_interface.html#a37421ea9a0ba554f11d4fb63b4b0943da4cfa5dc6b45d01386fd820c362ef9f8e", null ],
      [ "ReserveGroupChildren", "class_i_navigator_callback_interface.html#a37421ea9a0ba554f11d4fb63b4b0943da362c26c12ccdad47eb8e59becafb97b1", null ],
      [ "ReleaseNode", "class_i_navigator_callback_interface.html#a37421ea9a0ba554f11d4fb63b4b0943da3704e01474fd81c5ba1b30bea48d7f62", null ],
      [ "ReleaseGroupChildren", "class_i_navigator_callback_interface.html#a37421ea9a0ba554f11d4fb63b4b0943da72a7b231b7c284a52ff7d5ab3915c241", null ],
      [ "RequestNode", "class_i_navigator_callback_interface.html#a37421ea9a0ba554f11d4fb63b4b0943da4387c918e0b798c8b8ffe57da4746b41", null ]
    ] ],
    [ "CreateIDFStore", "class_i_navigator_callback_interface.html#a688e6d376ece0ea365b65de335b55e72", null ],
    [ "DeleteItem", "class_i_navigator_callback_interface.html#a1cbb4452cafb7cdfa0f98e66ba3080aa", null ],
    [ "ExecuteMergePostProcess", "class_i_navigator_callback_interface.html#a07abe098a2cad16544612eaed3c9446b", null ],
    [ "GetContextMenuCommandString", "class_i_navigator_callback_interface.html#ad2900da3c472de8b96940683aa7d437f", null ],
    [ "GetElemsForDrawingCheck", "class_i_navigator_callback_interface.html#af76c214c35ef9427fdbd62c6e371f4f5", null ],
    [ "GetIcon", "class_i_navigator_callback_interface.html#a8218dce38a0a35f03cbe591861ce44c1", null ],
    [ "GetTWCommandMailString", "class_i_navigator_callback_interface.html#a723da161e6c0c2bb7bd0cc6d662ddf6e", null ],
    [ "GetTWCommandMenuString", "class_i_navigator_callback_interface.html#aaa15608073f0c311e8321a79c5b8c26e", null ],
    [ "IsContextMenuCommandEnabled", "class_i_navigator_callback_interface.html#a770db702358b733f9ef653c11b6c9f16", null ],
    [ "IsDummyInterface", "class_i_navigator_callback_interface.html#a8c10a64e4c65f159b05299031cc78029", null ],
    [ "NewItem", "class_i_navigator_callback_interface.html#a82e4d9cbbab42bd2722c3c63167912ff", null ],
    [ "OpenSettings", "class_i_navigator_callback_interface.html#a0c635bab60763566a2fcb9fda8df9559", null ],
    [ "OpenView", "class_i_navigator_callback_interface.html#afc05a0fce9d0d4eddd6b9908b00f3d25", null ],
    [ "RenameItem", "class_i_navigator_callback_interface.html#a2d143c3bedffbbadc0f0ca1a48c339c3", null ]
];