var class_i_f_c_a_p_i_1_1v1_1_1_property_list_value =
[
    [ "GetListValues", "group___i_f_c.html#gaefc3f3b6a254a62814da17c32bd1d0fa", null ]
];