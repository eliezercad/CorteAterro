var class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_take_off_u_i_manager =
[
    [ "ApplyTakeOffDefaultToToolUIData", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_take_off_u_i_manager.html#a39e0d173d106cfda33b8485dfd552478", null ],
    [ "CreateTakeOffDefaultFromToolUIData", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_take_off_u_i_manager.html#a2d3cf3c2351df7705a5fa0e4416c0d8c", null ],
    [ "CreateTakeOffUIManager", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_take_off_u_i_manager.html#a222eea59a3f97086bf68803d669660f9", null ]
];