var class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_i_calculation_result_column =
[
    [ "~ICalculationResultColumn", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_i_calculation_result_column.html#a62fa510c4c14220a3b9edbfc363ac955", null ],
    [ "FormatValueToDisplayText", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_i_calculation_result_column.html#a008f0f9b563337cf6a103265da4198ae", null ],
    [ "GetDefaultWidth", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_i_calculation_result_column.html#a0e9a31b6a8798ffdcfd0001481d24246", null ],
    [ "GetId", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_i_calculation_result_column.html#a9e1777760124cb9f2e89858987522b72", null ],
    [ "GetTitle", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_i_calculation_result_column.html#a5b86f774014428ce7643b04dae1dea9f", null ],
    [ "GetUnitToDisplay", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_i_calculation_result_column.html#a405f24ad834c687c7aae7fcb351b94aa", null ],
    [ "IsEqual", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_i_calculation_result_column.html#af48f039b93337ac145111458691b2f38", null ],
    [ "IsLess", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_i_calculation_result_column.html#a96ca0f58148ff7ecdfa9f0d02731f8f8", null ]
];