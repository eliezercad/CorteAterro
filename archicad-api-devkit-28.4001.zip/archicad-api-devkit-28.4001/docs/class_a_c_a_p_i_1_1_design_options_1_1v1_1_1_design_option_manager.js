var class_a_c_a_p_i_1_1_design_options_1_1v1_1_1_design_option_manager =
[
    [ "GetAvailableDesignOptionCombinations", "class_a_c_a_p_i_1_1_design_options_1_1v1_1_1_design_option_manager.html#a034218286ded12ea687753f4f3e45a8e", null ],
    [ "GetDesignOptionCombinationSettingsOf", "class_a_c_a_p_i_1_1_design_options_1_1v1_1_1_design_option_manager.html#a0eacce1cb067d79eab2e19e9822265b9", null ]
];