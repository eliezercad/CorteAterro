var class_i_f_c_a_p_i_1_1v1_1_1_property_accessor =
[
    [ "PropertyAccessor", "group___i_f_c.html#gad963e5eb829aab389b3fed967ccca870", null ],
    [ "GetAttributes", "group___i_f_c.html#gacdb109a0be3a71108bfc9aa5b175e647", null ],
    [ "GetLocalClassificationReferences", "group___i_f_c.html#gabf58b2a1fba25320272829ddfc67ee8a", null ],
    [ "GetLocalProperties", "group___i_f_c.html#gabfec3dedde285fbaf724a40c816170c5", null ],
    [ "GetPreviewClassificationReferences", "group___i_f_c.html#ga2becf9e23581cb8af92d9aab0a212819", null ],
    [ "GetPreviewProperties", "group___i_f_c.html#gafa31a8702f469bad26dbaf1c1dd270fb", null ]
];