var class_i_f_c_a_p_i_1_1v1_1_1_property_table_value =
[
    [ "GetDefinedValues", "group___i_f_c.html#ga88392b9b092b659f4c4d75461e287d64", null ],
    [ "GetDefiningValues", "group___i_f_c.html#gaa66889dfa81e970709cd217c68d43271", null ]
];