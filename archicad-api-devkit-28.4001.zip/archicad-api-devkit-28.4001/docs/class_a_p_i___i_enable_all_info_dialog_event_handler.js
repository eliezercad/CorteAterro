var class_a_p_i___i_enable_all_info_dialog_event_handler =
[
    [ "Dispatch", "class_a_p_i___i_enable_all_info_dialog_event_handler.html#ae8da686959b2e2d2696f28fabe99dd2e", null ],
    [ "GetName", "class_a_p_i___i_enable_all_info_dialog_event_handler.html#a60a3d9120aae6c771dfcdf4eb8b38c35", null ]
];