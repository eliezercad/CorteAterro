var class_a_p_i___i_event_handler =
[
    [ "Dispatch", "class_a_p_i___i_event_handler.html#a737de79405b9cb00dec26027b45029e3", null ],
    [ "GetName", "class_a_p_i___i_event_handler.html#a7c7ae5ce57107f883461c9c56723311a", null ]
];