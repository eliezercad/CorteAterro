var class_a_p_i___i_property_group_event_handler =
[
    [ "Dispatch", "class_a_p_i___i_property_group_event_handler.html#a2ef01f6bf7a8733b6557b5951fd01a12", null ],
    [ "GetName", "class_a_p_i___i_property_group_event_handler.html#a2bee77e6c6673e770de2a2975ab74321", null ]
];