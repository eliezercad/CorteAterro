var class_i_f_c_a_p_i_1_1v1_1_1_hook_manager =
[
    [ "AssignmentsHookFunction", "group___i_f_c.html#ga3742204f23f825863b5d76aad462bdff", null ],
    [ "AttributeHookFunction", "group___i_f_c.html#ga643ad3d5c7897bccd4b338ecb4c6d814", null ],
    [ "ClassificationReferenceHookFunction", "group___i_f_c.html#gae5716b7923fd3474a0295e89a27be28c", null ],
    [ "PropertyHookFunction", "group___i_f_c.html#gac4de59e73f27e54a1df548879902e25b", null ],
    [ "RegisterAssignmentsHook", "group___i_f_c.html#ga934237a376c3a1bd884cfa492fe496b0", null ],
    [ "RegisterAttributeHook", "group___i_f_c.html#gae8b9fc079e1f30fc921e514769c70e84", null ],
    [ "RegisterClassificationReferenceHook", "group___i_f_c.html#gab94a196af2438a3292192c64d7a98bce", null ],
    [ "RegisterPropertyHook", "group___i_f_c.html#ga47bbb78567813aafbace6d884478a260", null ],
    [ "RegisterTypeObjectAttributeHook", "group___i_f_c.html#gae6906f5fb1bc948e3eff0eaf3d19d072", null ],
    [ "RegisterTypeObjectClassificationReferenceHook", "group___i_f_c.html#gabbf0342b967330c3482ddcc39276db9f", null ],
    [ "RegisterTypeObjectPropertyHook", "group___i_f_c.html#gaa6b47fee19c7f8c045f159498672757a", null ],
    [ "UnregisterAssignmentsHook", "group___i_f_c.html#ga1c7bfb0a8f2be9827e1d81fb13444afe", null ],
    [ "UnregisterAttributeHook", "group___i_f_c.html#ga27bc79b34f04cfee73d6cb3e65c2487e", null ],
    [ "UnregisterClassificationReferenceHook", "group___i_f_c.html#ga585b4399f6f48685ea1122b568b2d7af", null ],
    [ "UnregisterPropertyHook", "group___i_f_c.html#ga8a951b2f22e5fb81b2b8e56d190d0cb8", null ],
    [ "UnregisterTypeObjectAttributeHook", "group___i_f_c.html#gad809228d4dbd65ee41db3a8d825d9890", null ],
    [ "UnregisterTypeObjectClassificationReferenceHook", "group___i_f_c.html#ga56fe1d1abc7272ba4a91469a3a75ffc2", null ],
    [ "UnregisterTypeObjectPropertyHook", "group___i_f_c.html#ga9470582ea59ae6856da52eca7a140f8d", null ],
    [ "GetHookManager", "class_i_f_c_a_p_i_1_1v1_1_1_hook_manager.html#afc0465873d186ee58b64d5e01f58b5d5", null ]
];