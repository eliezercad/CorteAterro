var class_geometry_1_1_g_j_k_result =
[
    [ "CollisionType", "class_geometry_1_1_g_j_k_result.html#a0e09dea42567cdfface83ee591955d25", [
      [ "UNDEFINED", "class_geometry_1_1_g_j_k_result.html#a0e09dea42567cdfface83ee591955d25a0db45d2a4141101bdfe48e3314cfbca3", null ],
      [ "COLLISION", "class_geometry_1_1_g_j_k_result.html#a0e09dea42567cdfface83ee591955d25afc3ca10632f0c7aa3aaea07a234377db", null ],
      [ "NO_COLLISION", "class_geometry_1_1_g_j_k_result.html#a0e09dea42567cdfface83ee591955d25a874a40b8eb0a1602fae9e93767a85f08", null ],
      [ "COLLISION_NOT_FOUND", "class_geometry_1_1_g_j_k_result.html#a0e09dea42567cdfface83ee591955d25a91e9bc93f5b341e90d020d79196585f9", null ]
    ] ],
    [ "IsCloser", "class_geometry_1_1_g_j_k_result.html#afaffdeb1e66b94c714afccafbd4e107c", null ],
    [ "IsCollided", "class_geometry_1_1_g_j_k_result.html#ae416232dda8337229975e8e95ccb6040", null ],
    [ "IsNotFound", "class_geometry_1_1_g_j_k_result.html#a2383eb266ab21622869881478df93384", null ],
    [ "operator bool", "class_geometry_1_1_g_j_k_result.html#a9523850075ea38a000d2d50b582f9339", null ]
];