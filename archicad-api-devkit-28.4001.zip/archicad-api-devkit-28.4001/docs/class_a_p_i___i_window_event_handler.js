var class_a_p_i___i_window_event_handler =
[
    [ "Dispatch", "class_a_p_i___i_window_event_handler.html#ae8ab7753f64543d8e2b7575607472684", null ],
    [ "GetName", "class_a_p_i___i_window_event_handler.html#a38a6b9393d86baa3b4d2017cb2245468", null ],
    [ "OnWindowBroughtForward", "class_a_p_i___i_window_event_handler.html#a820daa33863d227cccdc2a3d69d1f5e5", null ],
    [ "OnWindowSentBackward", "class_a_p_i___i_window_event_handler.html#afbc10410c92306ea22e8e47203973b38", null ]
];