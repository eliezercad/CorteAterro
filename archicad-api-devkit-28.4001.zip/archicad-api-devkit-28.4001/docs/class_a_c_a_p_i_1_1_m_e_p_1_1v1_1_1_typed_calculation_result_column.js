var class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_typed_calculation_result_column =
[
    [ "FormatValueToDisplayText", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_typed_calculation_result_column.html#a412ff7d8c51c7f3d643aaf238f7fe6f3", null ],
    [ "IsEqual", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_typed_calculation_result_column.html#a621a3bfec587f5e6b90d94e9ae4cde34", null ],
    [ "IsLess", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_typed_calculation_result_column.html#a8753142c2d330d4b13b169d429f0bf56", null ]
];