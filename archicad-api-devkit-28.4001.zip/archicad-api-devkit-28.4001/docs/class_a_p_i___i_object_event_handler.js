var class_a_p_i___i_object_event_handler =
[
    [ "OnCreated", "class_a_p_i___i_object_event_handler.html#a9a02da786dd5b13dafff1ab0c78adb63", null ],
    [ "OnDeleted", "class_a_p_i___i_object_event_handler.html#a1486d47418ddf3ba361751e22a6a54a7", null ],
    [ "OnModified", "class_a_p_i___i_object_event_handler.html#a0b762b011161221dc6627a9960a16db9", null ]
];