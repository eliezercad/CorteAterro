var class_i_f_c_a_p_i_1_1v1_1_1_assignments =
[
    [ "GetChildObjectTable", "group___i_f_c.html#ga6f9d87eabc5258281742a242d12cc034", null ],
    [ "GetParentObjectTable", "group___i_f_c.html#ga95a896d0a063cb06a2198242fc12bff3", null ],
    [ "GetRootGroups", "group___i_f_c.html#ga6c21decf514800a19e8d7ecfddc2c0d0", null ]
];