var class_a_c_a_p_i_1_1_a_p_i___i_keynote_folder_event_handler =
[
    [ "Dispatch", "class_a_c_a_p_i_1_1_a_p_i___i_keynote_folder_event_handler.html#ae049ed2cfaff28b6d342591bda8755a1", null ],
    [ "GetName", "class_a_c_a_p_i_1_1_a_p_i___i_keynote_folder_event_handler.html#a232595c08c93d009b46f9fc778d0a478", null ]
];