var class_a_c_a_p_i_1_1_design_options_1_1v1_1_1_design_option_combination =
[
    [ "GetGuid", "class_a_c_a_p_i_1_1_design_options_1_1v1_1_1_design_option_combination.html#a493dc705535a36e191f4fed6f1cc57a2", null ],
    [ "GetName", "class_a_c_a_p_i_1_1_design_options_1_1v1_1_1_design_option_combination.html#a3a3c983f537e422b53ba9466873dd913", null ]
];