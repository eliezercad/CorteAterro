var class_a_p_i___add_on_command =
[
    [ "Execute", "class_a_p_i___add_on_command.html#ab8aa84d0a15a5ce43e45c38fe33b675c", null ],
    [ "GetExecutionPolicy", "class_a_p_i___add_on_command.html#a8428b4291ed612747c36af9878690eb0", null ],
    [ "GetInputParametersSchema", "class_a_p_i___add_on_command.html#acb82b80e67a526ec2a3a7af87764053f", null ],
    [ "GetName", "class_a_p_i___add_on_command.html#ae02570f81fe4ada353626adae6e0d9f2", null ],
    [ "GetNamespace", "class_a_p_i___add_on_command.html#a68cc0d51c00f0175a92780f9c9c8d52c", null ],
    [ "GetResponseSchema", "class_a_p_i___add_on_command.html#aa960031f806786e0dc1699aeb1861f37", null ],
    [ "GetSchemaDefinitions", "class_a_p_i___add_on_command.html#ad962ece5fc34d952471b7a1583cab735", null ],
    [ "IsProcessWindowVisible", "class_a_p_i___add_on_command.html#a3fb67dd8a9e1ba7205be99c58c7f9203", null ],
    [ "OnResponseValidationFailed", "class_a_p_i___add_on_command.html#aae63c704e49b911a9d10a45c9b86210d", null ]
];