var class_i_f_c_a_p_i_1_1v1_1_1_hook_assignments =
[
    [ "AssignObjects", "group___i_f_c.html#ga25748af4632bedd8c46f641b036aece0", null ],
    [ "CreateIfcGroup", "group___i_f_c.html#ga8fa9d78549b173fa58eade125cff49ed", null ],
    [ "GetIfcRelAssignsToGroup", "group___i_f_c.html#ga62ec728704dc2f8355d1a486c1c982b8", null ],
    [ "GetIfcRelServicesBuildings", "group___i_f_c.html#gaa11d6780e3d6820ead34f43636ab8302", null ],
    [ "ServiceBuildings", "group___i_f_c.html#ga769e670fcd7ddc7f507cd609343c9174", null ]
];