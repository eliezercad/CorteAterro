var class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_take_off_default =
[
    [ "Place", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_take_off_default.html#a0045db787c90a5fd6797feb527d6e633", null ],
    [ "CreateTakeOffDefault", "class_a_c_a_p_i_1_1_m_e_p_1_1v1_1_1_take_off_default.html#a3d48f69e0d0a96a32dbefcc5b69efbd7", null ]
];