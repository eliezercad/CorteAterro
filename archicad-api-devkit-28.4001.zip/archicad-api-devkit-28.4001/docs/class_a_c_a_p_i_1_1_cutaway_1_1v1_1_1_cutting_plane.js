var class_a_c_a_p_i_1_1_cutaway_1_1v1_1_1_cutting_plane =
[
    [ "AreCuttingPlanesVisible", "group___cutting_plane_management.html#gada87fe0cb56531ce1f381b2fd000a0bd", null ],
    [ "Is3DCutawayEnabled", "group___cutting_plane_management.html#ga7993c0966dbed4a5550c5f54afaa7f5d", null ],
    [ "Set3DCutawayStatus", "group___cutting_plane_management.html#gac5e84dfecdae74a01c82474d5b378af0", null ],
    [ "SetCuttingPlanesVisibility", "group___cutting_plane_management.html#ga869e1239f210e62b4336e22bd0d8f283", null ],
    [ "GetCuttingPlane", "class_a_c_a_p_i_1_1_cutaway_1_1v1_1_1_cutting_plane.html#a3eb52bbfde68c0ff2ae7e1280386cf3b", null ]
];