var class_a_c_a_p_i_1_1v1_1_1_zone_boundary_query =
[
    [ "GetZoneBoundaries", "class_a_c_a_p_i_1_1v1_1_1_zone_boundary_query.html#a32b3f4f74ba1bdf44acc68d9665c2311", null ],
    [ "Modify", "class_a_c_a_p_i_1_1v1_1_1_zone_boundary_query.html#ae7c336ddf007d90b807dceea56bf08f9", null ],
    [ "Update", "class_a_c_a_p_i_1_1v1_1_1_zone_boundary_query.html#a0444abcc24a9dd919220f738a29f999e", null ],
    [ "CreateZoneBoundaryQuery", "class_a_c_a_p_i_1_1v1_1_1_zone_boundary_query.html#a94c904874e0297d4a73cfeb82a94f3be", null ]
];