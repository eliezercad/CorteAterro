var class_i_f_c_a_p_i_1_1v1_1_1_property_enumerated_value =
[
    [ "GetEnumerationReference", "group___i_f_c.html#gac2404d3cdf3bc3fa346a4cdf413b76aa", null ],
    [ "GetEnumerationValues", "group___i_f_c.html#ga3f31c1f6a86dedf253cac374beeea180", null ]
];