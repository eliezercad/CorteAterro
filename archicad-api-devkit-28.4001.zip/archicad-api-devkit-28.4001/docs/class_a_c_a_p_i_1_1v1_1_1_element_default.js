var class_a_c_a_p_i_1_1v1_1_1_element_default =
[
    [ "ElementDefault", "class_a_c_a_p_i_1_1v1_1_1_element_default.html#ae54b72efef492a46cfcfe6fcd7c22350", null ],
    [ "SetAsArchicadDefault", "class_a_c_a_p_i_1_1v1_1_1_element_default.html#a73b53faf9033aeccf5252139d6f246e1", null ]
];