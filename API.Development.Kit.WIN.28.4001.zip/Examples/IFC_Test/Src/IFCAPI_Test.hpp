﻿#ifndef	IFCAPI_TEST_HPP
#define	IFCAPI_TEST_HPP

void GetStories ();
void GetAssignmentTree ();
void GetAllObjectsLocalProperties ();
void GetAllObjectsPreviewProperties ();
void GetContainingGroupsOfSelection ();
void FindElementsByIFCGlobalId ();

#endif
