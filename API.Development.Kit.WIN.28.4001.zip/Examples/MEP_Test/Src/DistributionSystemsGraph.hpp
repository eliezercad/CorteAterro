#ifndef GS_MEP_TEST_DISTRIBUTIONSYSTEMSGRAPH_HPP
#define GS_MEP_TEST_DISTRIBUTIONSYSTEMSGRAPH_HPP

// GSRoot
#include "Definitions.hpp"


namespace MEPExample {


GSErrCode LabelConnectionsInGraph ();


} // namespace MEPExample


#endif
