// GSRoot
#include "Definitions.hpp"


namespace MEPExample {


GSErrCode QuerySelectedElementDetails ();


GSErrCode QueryDefaultDetails ();


}