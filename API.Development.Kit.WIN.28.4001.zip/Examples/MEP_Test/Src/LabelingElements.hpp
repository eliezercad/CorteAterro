#ifndef GS_MEP_TEST_LABELINGELEMENTS_HPP
#define GS_MEP_TEST_LABELINGELEMENTS_HPP

// GSRoot
#include "Definitions.hpp"


namespace MEPExample {


GSErrCode LabelSubelementsOfSelectedRoute ();


GSErrCode LabelSelectedMEPElements ();


} // namespace MEPExample


#endif
