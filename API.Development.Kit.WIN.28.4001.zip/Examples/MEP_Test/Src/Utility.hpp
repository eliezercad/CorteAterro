// GSRoot
#include "Definitions.hpp"

namespace MEPExample {


GSErrCode CreateElementSetFromSelectedElements ();


GSErrCode CreateElementLinksBetweenSelectedElements ();


}