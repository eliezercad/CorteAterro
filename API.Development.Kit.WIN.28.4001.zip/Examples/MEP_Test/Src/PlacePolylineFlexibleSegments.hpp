// GSRoot
#include "Definitions.hpp"

namespace MEPExample {


GSErrCode PlacePolylineFlexibleSegments ();


} // namespace MEPExample
