#ifndef GS_MEP_TEST_GRAPHCALCULATIONINTERFACE_HPP
#define GS_MEP_TEST_GRAPHCALCULATIONINTERFACE_HPP

// GSRoot
#include "Definitions.hpp"


namespace MEPExample {

GSErrCode UseCalculationInterface ();

} // namespace MEPExample


#endif
