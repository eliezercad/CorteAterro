#if !defined (RESOURCES_HPP)
#define RESOURCES_HPP

#define	DESIGNOPTIONS_TEST_ADDON_NAME			32000	//'STR#' 32000
#define	DESIGNOPTIONS_TEST_MENU_STRINGS			32500	//'STR#' 32500
#define	DESIGNOPTIONS_TEST_MENU_PROMPT_STRINGS	32600	//'STR#' 32600

enum MenuItem {
	DumpViewMapDesignOptionCombinationsID = 1,
	SetAllDesignOptionCombinationsToMainModelOnlyID = 2,
	DumpAvailableDesignOptionCombinationsID = 3,
	DumpDesignOptionRelatedInfoForSelectedElementsID = 4
};

#endif