// *****************************************************************************
// File:			Classification_Test.hpp
// Description:		Classification_Test add-on test functions
// Project:			APITools/Classification_Test
// Namespace:		-
// Contact person:	CSAT
// SG compatible
// *****************************************************************************

// --- Includes ----------------------------------------------------------------

#include	"APIEnvir.h"
#include	"ACAPinc.h"

#include	"DGModule.hpp"
