// *****************************************************************************
// Header file for primitive dumper
// Mac/Win
//
// Namespaces:        Contact person:
//     -None-			Somorjai
//
// [SG compatible] - Yes
// *****************************************************************************

void DumpPrimitive (const API_PrimElement* primElem,
					const void* par1, const void* par2, const void* par3);
